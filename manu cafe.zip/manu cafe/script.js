/**
 * ==========================================================================
 * MANASA CAFE - Main JavaScript File
 * Handles Navigation, Cart Calculations, Menu/Gallery Filtering, Lightbox,
 * Reservation Form Validation, Review Submissions, and Interactive UI
 * ==========================================================================
 */

// --- Global State & Storage ---
let cart = JSON.parse(localStorage.getItem('manasa_cart')) || [];
let currentLightboxIndex = 0;
let galleryImagesList = [];

// --- DOM Ready Initialization ---
document.addEventListener('DOMContentLoaded', () => {
    initNavigation();
    initScrollEffects();
    updateCartUI();
    initMenuFilters();
    initGalleryFilters();
    initStarRating();
    initReservationDatePicker();
    initLightboxKeyboard();
});

/* ==========================================================================
   1. Navigation & Scroll Effects
   ========================================================================== */
function initNavigation() {
    const mobileToggle = document.getElementById('mobileToggle');
    const navLinks = document.getElementById('navLinks');
    const header = document.getElementById('mainHeader');

    // Mobile Hamburger Menu Toggle
    if (mobileToggle && navLinks) {
        mobileToggle.addEventListener('click', (e) => {
            e.stopPropagation();
            navLinks.classList.toggle('active');
            const icon = mobileToggle.querySelector('i');
            if (navLinks.classList.contains('active')) {
                icon.classList.remove('fa-bars');
                icon.classList.add('fa-xmark');
            } else {
                icon.classList.remove('fa-xmark');
                icon.classList.add('fa-bars');
            }
        });

        // Close mobile nav when clicking outside
        document.addEventListener('click', (e) => {
            if (navLinks.classList.contains('active') && !navLinks.contains(e.target) && !mobileToggle.contains(e.target)) {
                navLinks.classList.remove('active');
                const icon = mobileToggle.querySelector('i');
                if (icon) {
                    icon.classList.remove('fa-xmark');
                    icon.classList.add('fa-bars');
                }
            }
        });
    }

    // Highlight active link based on current page url
    const currentPath = window.location.pathname.split('/').pop() || 'index.html';
    const allNavLinks = document.querySelectorAll('.nav-link');
    allNavLinks.forEach(link => {
        const linkPath = link.getAttribute('href');
        if (linkPath === currentPath || (currentPath === '' && linkPath === 'index.html')) {
            link.classList.add('active');
        } else if (linkPath !== currentPath) {
            link.classList.remove('active');
        }
    });

    // Back to top button logic
    const backToTopBtn = document.getElementById('backToTop');
    if (backToTopBtn) {
        window.addEventListener('scroll', () => {
            if (window.scrollY > 400) {
                backToTopBtn.classList.add('visible');
            } else {
                backToTopBtn.classList.remove('visible');
            }
        });

        backToTopBtn.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }
}

function initScrollEffects() {
    const header = document.getElementById('mainHeader');
    window.addEventListener('scroll', () => {
        if (window.scrollY > 50) {
            header.classList.add('scrolled');
        } else {
            header.classList.remove('scrolled');
        }
    });
}

/* ==========================================================================
   2. Take Away Shopping Cart System (Calculation & Storage)
   ========================================================================== */
function saveCart() {
    localStorage.setItem('manasa_cart', JSON.stringify(cart));
    updateCartUI();
}

// Add item to cart
function addToCart(id, name, price, img) {
    const existingIndex = cart.findIndex(item => item.id === id);
    if (existingIndex > -1) {
        cart[existingIndex].qty += 1;
    } else {
        cart.push({
            id: id,
            name: name,
            price: Number(price),
            qty: 1,
            img: img || ''
        });
    }
    saveCart();
    showToast(`Added "${name}" to Take Away order!`, 'fa-bag-shopping');
}

// Attach event listeners for all Add-to-Cart buttons
document.addEventListener('click', (e) => {
    const btn = e.target.closest('.add-to-cart-btn');
    if (btn) {
        const id = btn.getAttribute('data-id');
        const name = btn.getAttribute('data-name');
        const price = btn.getAttribute('data-price');
        const img = btn.getAttribute('data-img');
        addToCart(id, name, price, img);
    }
});

// Update Cart UI (Nav Badge & Order Summary List on Take Away Page)
function updateCartUI() {
    // 1. Update Navigation Badge Count
    const totalCount = cart.reduce((sum, item) => sum + item.qty, 0);
    const navBadges = document.querySelectorAll('#navCartCount');
    navBadges.forEach(badge => {
        badge.textContent = totalCount;
    });

    // 2. Update Order Summary Sidebar if on takeaway.html
    const cartList = document.getElementById('cartItemsList');
    const subtotalEl = document.getElementById('cartSubtotal');
    const taxEl = document.getElementById('cartTax');
    const grandTotalEl = document.getElementById('cartGrandTotal');
    const placeOrderBtn = document.getElementById('placeOrderBtn');

    if (!cartList) return; // Not on takeaway page

    if (cart.length === 0) {
        cartList.innerHTML = `
            <div class="cart-empty-message">
                <i class="fa-solid fa-basket-shopping"></i>
                Your take away basket is empty.<br>Add delicious items to begin!
            </div>
        `;
        if (subtotalEl) subtotalEl.textContent = '₹0';
        if (taxEl) taxEl.textContent = '₹0';
        if (grandTotalEl) grandTotalEl.textContent = '₹0';
        if (placeOrderBtn) placeOrderBtn.disabled = true;
        return;
    }

    // Render cart items
    let itemsHTML = '';
    let subtotal = 0;

    cart.forEach((item, index) => {
        const itemTotal = item.price * item.qty;
        subtotal += itemTotal;
        itemsHTML += `
            <div class="cart-item-row">
                <div style="flex-grow: 1;">
                    <span class="cart-item-name">${item.name}</span>
                    <span class="cart-item-qty-price">₹${item.price} × ${item.qty}</span>
                </div>
                <div style="display: flex; align-items: center;">
                    <div class="quantity-control" style="transform: scale(0.85); margin-right: 0.5rem;">
                        <button type="button" class="qty-btn" onclick="changeCartItemQty(${index}, -1)">-</button>
                        <span class="qty-display">${item.qty}</span>
                        <button type="button" class="qty-btn" onclick="changeCartItemQty(${index}, 1)">+</button>
                    </div>
                    <span class="cart-item-total">₹${itemTotal}</span>
                    <span class="cart-item-remove" onclick="removeCartItem(${index})" title="Remove item">
                        <i class="fa-solid fa-xmark"></i>
                    </span>
                </div>
            </div>
        `;
    });

    cartList.innerHTML = itemsHTML;

    // Computation: 5% GST + ₹20 Eco Packaging Box
    const tax = Math.round(subtotal * 0.05);
    const packaging = 20;
    const grandTotal = subtotal + tax + packaging;

    if (subtotalEl) subtotalEl.textContent = `₹${subtotal}`;
    if (taxEl) taxEl.textContent = `₹${tax}`;
    if (grandTotalEl) grandTotalEl.textContent = `₹${grandTotal}`;
    if (placeOrderBtn) placeOrderBtn.disabled = false;
}

// Modify cart item quantity (+ / -)
function changeCartItemQty(index, change) {
    if (cart[index]) {
        cart[index].qty += change;
        if (cart[index].qty <= 0) {
            cart.splice(index, 1);
        }
        saveCart();
    }
}

// Remove item from cart
function removeCartItem(index) {
    if (cart[index]) {
        const removedName = cart[index].name;
        cart.splice(index, 1);
        saveCart();
        showToast(`Removed "${removedName}"`, 'fa-trash');
    }
}

// Clear Entire Cart
const clearCartBtn = document.getElementById('clearCartBtn');
if (clearCartBtn) {
    clearCartBtn.addEventListener('click', () => {
        if (cart.length === 0) return;
        if (confirm('Are you sure you want to clear your take-away cart?')) {
            cart = [];
            saveCart();
            showToast('Take away cart cleared.', 'fa-trash');
        }
    });
}

// Handle Take Away Checkout Form Submission
function handleTakeawayCheckout(event) {
    event.preventDefault();
    if (cart.length === 0) {
        showToast('Your cart is empty! Please add items first.', 'fa-circle-exclamation');
        return;
    }

    const name = document.getElementById('takeawayName').value.trim();
    const phone = document.getElementById('takeawayPhone').value.trim();
    const time = document.getElementById('takeawayTime').value;
    const notes = document.getElementById('takeawayNotes').value.trim();

    if (!name || !phone || !time) {
        showToast('Please fill out all required pickup fields.', 'fa-circle-exclamation');
        return;
    }

    // Compute totals
    let subtotal = cart.reduce((sum, item) => sum + (item.price * item.qty), 0);
    let tax = Math.round(subtotal * 0.05);
    let packaging = 20;
    let grandTotal = subtotal + tax + packaging;

    // Generate Order ID
    const orderId = 'MNS-ORD-' + Math.floor(10000 + Math.random() * 90000);

    // Build Receipt HTML
    let receiptHTML = `
        <div class="receipt-row">
            <span><strong>Order ID:</strong></span>
            <span class="text-gold"><strong>${orderId}</strong></span>
        </div>
        <div class="receipt-row">
            <span>Pickup Time:</span>
            <span>${time}</span>
        </div>
        <div class="receipt-row">
            <span>Contact Phone:</span>
            <span>${phone}</span>
        </div>
        ${notes ? `<div class="receipt-row"><span>Notes:</span><span>${notes}</span></div>` : ''}
        <div style="border-top: 1px dashed rgba(212,175,55,0.3); margin: 0.6rem 0; padding-top: 0.6rem;">
            <strong>Items Ordered:</strong>
        </div>
    `;

    cart.forEach(item => {
        receiptHTML += `
            <div class="receipt-row" style="font-size: 0.85rem;">
                <span>${item.name} (×${item.qty})</span>
                <span>₹${item.price * item.qty}</span>
            </div>
        `;
    });

    receiptHTML += `
        <div style="border-top: 1px solid rgba(255,255,255,0.15); margin-top: 0.6rem; padding-top: 0.6rem;">
            <div class="receipt-row">
                <span>Subtotal:</span>
                <span>₹${subtotal}</span>
            </div>
            <div class="receipt-row">
                <span>GST (5%) & Packaging:</span>
                <span>₹${tax + packaging}</span>
            </div>
            <div class="receipt-row" style="font-size: 1.1rem; font-weight: 700; color: var(--color-gold-light);">
                <span>Grand Total:</span>
                <span>₹${grandTotal}</span>
            </div>
        </div>
    `;

    // Populate Modal
    const modalCustomerName = document.getElementById('modalCustomerName');
    const modalReceiptDetails = document.getElementById('modalReceiptDetails');
    const orderModal = document.getElementById('orderConfirmModal');

    if (modalCustomerName) modalCustomerName.textContent = name;
    if (modalReceiptDetails) modalReceiptDetails.innerHTML = receiptHTML;
    if (orderModal) orderModal.classList.add('active');

    // Reset Form & Clear Cart
    document.getElementById('takeawayOrderForm').reset();
    cart = [];
    saveCart();
    showToast(`Order #${orderId} placed successfully!`, 'fa-circle-check');
}

function closeOrderModal() {
    const orderModal = document.getElementById('orderConfirmModal');
    if (orderModal) orderModal.classList.remove('active');
}

/* ==========================================================================
   3. Menu Page Filters & Live Search
   ========================================================================== */
function initMenuFilters() {
    const filterBtns = document.querySelectorAll('.menu-filter-bar .filter-btn[data-category]');
    const searchInput = document.getElementById('menuSearchInput');
    const menuCards = document.querySelectorAll('#menuGridContainer .menu-card');

    if (filterBtns.length === 0 && !searchInput) return;

    function applyFilterAndSearch() {
        const activeBtn = document.querySelector('.menu-filter-bar .filter-btn.active');
        const selectedCat = activeBtn ? activeBtn.getAttribute('data-category') : 'all';
        const query = searchInput ? searchInput.value.toLowerCase().trim() : '';

        menuCards.forEach(card => {
            const cardCat = card.getAttribute('data-cat') || '';
            const cardTitle = (card.getAttribute('data-title') || '').toLowerCase();
            const cardDesc = (card.querySelector('.menu-card-desc')?.textContent || '').toLowerCase();

            const matchesCategory = (selectedCat === 'all' || cardCat === selectedCat);
            const matchesSearch = (query === '' || cardTitle.includes(query) || cardDesc.includes(query));

            if (matchesCategory && matchesSearch) {
                card.style.display = 'flex';
                card.style.animation = 'fadeIn 0.4s ease';
            } else {
                card.style.display = 'none';
            }
        });
    }

    filterBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            filterBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            applyFilterAndSearch();
        });
    });

    if (searchInput) {
        searchInput.addEventListener('input', applyFilterAndSearch);
    }
}

/* ==========================================================================
   4. Gallery Category Filtering & Fullscreen Lightbox
   ========================================================================== */
function initGalleryFilters() {
    const galleryFilterBtns = document.querySelectorAll('[data-gallery-filter]');
    const galleryItems = document.querySelectorAll('#galleryGrid .gallery-item');

    if (galleryFilterBtns.length === 0) return;

    galleryFilterBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            galleryFilterBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');

            const filter = btn.getAttribute('data-gallery-filter');
            galleryItems.forEach(item => {
                const itemCategory = item.getAttribute('data-category');
                if (filter === 'all' || itemCategory === filter) {
                    item.style.display = 'block';
                    item.style.animation = 'fadeIn 0.4s ease';
                } else {
                    item.style.display = 'none';
                }
            });
        });
    });
}

function openLightbox(imgSrc, caption) {
    const modal = document.getElementById('lightboxModal');
    const modalImg = document.getElementById('lightboxImg');
    const modalCaption = document.getElementById('lightboxCaption');

    // Collect all active gallery images for cycling
    galleryImagesList = [];
    const activeGalleryItems = document.querySelectorAll('.gallery-item');
    activeGalleryItems.forEach((item, idx) => {
        if (item.style.display !== 'none') {
            const img = item.querySelector('img');
            const h4 = item.querySelector('h4');
            if (img) {
                galleryImagesList.push({
                    src: img.src,
                    caption: h4 ? h4.textContent : 'MANASA CAFE View'
                });
                if (img.src === imgSrc || imgSrc.includes(img.src)) {
                    currentLightboxIndex = galleryImagesList.length - 1;
                }
            }
        }
    });

    if (modal && modalImg && modalCaption) {
        modalImg.src = imgSrc;
        modalCaption.textContent = caption || 'MANASA CAFE Beachside Moments';
        modal.classList.add('active');
    }
}

function closeLightbox() {
    const modal = document.getElementById('lightboxModal');
    if (modal) modal.classList.remove('active');
}

function nextLightboxImg() {
    if (galleryImagesList.length === 0) return;
    currentLightboxIndex = (currentLightboxIndex + 1) % galleryImagesList.length;
    const current = galleryImagesList[currentLightboxIndex];
    document.getElementById('lightboxImg').src = current.src;
    document.getElementById('lightboxCaption').textContent = current.caption;
}

function prevLightboxImg() {
    if (galleryImagesList.length === 0) return;
    currentLightboxIndex = (currentLightboxIndex - 1 + galleryImagesList.length) % galleryImagesList.length;
    const current = galleryImagesList[currentLightboxIndex];
    document.getElementById('lightboxImg').src = current.src;
    document.getElementById('lightboxCaption').textContent = current.caption;
}

function initLightboxKeyboard() {
    document.addEventListener('keydown', (e) => {
        const modal = document.getElementById('lightboxModal');
        if (modal && modal.classList.contains('active')) {
            if (e.key === 'Escape') closeLightbox();
            if (e.key === 'ArrowRight') nextLightboxImg();
            if (e.key === 'ArrowLeft') prevLightboxImg();
        }
    });
}

/* ==========================================================================
   5. Table Reservation Validation & Receipt Generation
   ========================================================================== */
function initReservationDatePicker() {
    const dateInput = document.getElementById('resDate');
    if (dateInput) {
        // Enforce minimum date to today so guests can't book in past
        const today = new Date().toISOString().split('T')[0];
        dateInput.setAttribute('min', today);
        dateInput.value = today;
    }
}

function handleReservationSubmit(event) {
    event.preventDefault();

    const name = document.getElementById('resName').value.trim();
    const phone = document.getElementById('resPhone').value.trim();
    const email = document.getElementById('resEmail').value.trim();
    const guests = document.getElementById('resGuests').value;
    const date = document.getElementById('resDate').value;
    const time = document.getElementById('resTime').value;
    const seating = document.getElementById('resSeating').value;
    const occasion = document.getElementById('resOccasion').value.trim();

    if (!name || !phone || !email || !date || !time || !seating) {
        showToast('Please fill all mandatory reservation fields.', 'fa-circle-exclamation');
        return;
    }

    // Generate unique reservation ID
    const resId = 'MNS-RES-' + Math.floor(10000 + Math.random() * 90000);

    const ticketHTML = `
        <div class="receipt-row">
            <span><strong>Booking Reference:</strong></span>
            <span class="text-gold"><strong>${resId}</strong></span>
        </div>
        <div class="receipt-row">
            <span>Guest Name:</span>
            <span>${name}</span>
        </div>
        <div class="receipt-row">
            <span>Date & Time:</span>
            <span>${date} | ${time}</span>
        </div>
        <div class="receipt-row">
            <span>Party Size:</span>
            <span>${guests}</span>
        </div>
        <div class="receipt-row">
            <span>Seating Zone:</span>
            <span class="text-gold">${seating}</span>
        </div>
        ${occasion ? `<div class="receipt-row"><span>Special Notes:</span><span>${occasion}</span></div>` : ''}
        <div class="receipt-row">
            <span>Status:</span>
            <span style="color:#4CAF50; font-weight:700;"><i class="fa-solid fa-circle-check"></i> Confirmed</span>
        </div>
    `;

    const ticketDetails = document.getElementById('resTicketDetails');
    const modal = document.getElementById('reservationConfirmModal');

    if (ticketDetails) ticketDetails.innerHTML = ticketHTML;
    if (modal) modal.classList.add('active');

    // Reset Form
    document.getElementById('reservationForm').reset();
    initReservationDatePicker();
    showToast(`Table booked successfully! Ref: ${resId}`, 'fa-circle-check');
}

function closeReservationModal() {
    const modal = document.getElementById('reservationConfirmModal');
    if (modal) modal.classList.remove('active');
}

/* ==========================================================================
   6. Reviews Star Rating Picker & Dynamic Submission
   ========================================================================== */
function initStarRating() {
    const starContainer = document.getElementById('starRatingSelector');
    const hiddenInput = document.getElementById('selectedStarValue');

    if (!starContainer || !hiddenInput) return;

    const stars = starContainer.querySelectorAll('i');

    stars.forEach(star => {
        star.addEventListener('click', () => {
            const rating = parseInt(star.getAttribute('data-rating'));
            hiddenInput.value = rating;

            stars.forEach((s, idx) => {
                if (idx < rating) {
                    s.classList.add('active');
                } else {
                    s.classList.remove('active');
                }
            });
        });
    });
}

function handleReviewFormSubmit(event) {
    event.preventDefault();

    const name = document.getElementById('reviewAuthor').value.trim();
    const city = document.getElementById('reviewCity').value.trim();
    const favItem = document.getElementById('reviewFavItem').value.trim() || 'Signature Coffee';
    const rating = parseInt(document.getElementById('selectedStarValue').value) || 5;
    const text = document.getElementById('reviewText').value.trim();

    if (!name || !city || !text) {
        showToast('Please provide your name, city, and review message.', 'fa-circle-exclamation');
        return;
    }

    // Build star icons
    let starsHTML = '';
    for (let i = 1; i <= 5; i++) {
        if (i <= rating) {
            starsHTML += '<i class="fa-solid fa-star"></i>';
        } else {
            starsHTML += '<i class="fa-regular fa-star"></i>';
        }
    }

    // Pick avatar placeholder
    const avatarList = [
        'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?q=80&w=150&auto=format&fit=crop',
        'https://images.unsplash.com/photo-1580489944761-15a19d654956?q=80&w=150&auto=format&fit=crop',
        'https://images.unsplash.com/photo-1527980965255-d3b416303d12?q=80&w=150&auto=format&fit=crop'
    ];
    const randomAvatar = avatarList[Math.floor(Math.random() * avatarList.length)];

    // Create New Review Card HTML
    const newCard = document.createElement('div');
    newCard.className = 'review-card';
    newCard.style.animation = 'fadeInDown 0.6s ease';
    newCard.innerHTML = `
        <div class="review-header">
            <div class="reviewer-profile">
                <img src="${randomAvatar}" alt="${name}" class="reviewer-avatar">
                <div>
                    <h4 class="reviewer-name">${name}</h4>
                    <span class="reviewer-tag"><i class="fa-solid fa-circle-check"></i> Verified Guest • ${city}</span>
                </div>
            </div>
            <div class="stars-row">${starsHTML}</div>
        </div>
        <p class="review-body">"${text}"</p>
        <div class="review-footer">
            <span>Visited: Just now</span>
            <span>Favorite: ${favItem}</span>
        </div>
    `;

    const reviewsGrid = document.getElementById('reviewsGridContainer');
    if (reviewsGrid) {
        reviewsGrid.prepend(newCard);
    }

    // Reset Form
    document.getElementById('reviewSubmitForm').reset();
    // Reset stars back to 5
    document.getElementById('selectedStarValue').value = 5;
    const stars = document.querySelectorAll('#starRatingSelector i');
    stars.forEach(s => s.classList.add('active'));

    showToast('Thank you for your lovely review!', 'fa-heart');
}

/* ==========================================================================
   7. Contact & Newsletter Form Handlers
   ========================================================================== */
function handleContactSubmit(event) {
    event.preventDefault();

    const name = document.getElementById('contactName').value.trim();
    const phone = document.getElementById('contactPhone').value.trim();
    const email = document.getElementById('contactEmail').value.trim();
    const subject = document.getElementById('contactSubject').value;
    const message = document.getElementById('contactMessage').value.trim();

    if (!name || !phone || !email || !message) {
        showToast('Please complete all contact form fields.', 'fa-circle-exclamation');
        return;
    }

    document.getElementById('contactForm').reset();
    showToast(`Thank you, ${name}! Your inquiry regarding "${subject}" has been sent.`, 'fa-paper-plane');
}

function handleNewsletterSubmit(event) {
    event.preventDefault();
    const emailInput = document.getElementById('newsletterEmail');
    if (emailInput && emailInput.value.trim()) {
        const email = emailInput.value.trim();
        emailInput.value = '';
        showToast(`Subscribed ${email}! Use coupon "SUNSET15" for 15% off.`, 'fa-gift');
    }
}

/* ==========================================================================
   8. Global Toast Notification System
   ========================================================================== */
function showToast(message, iconClass = 'fa-circle-check') {
    const toastContainer = document.getElementById('toastContainer');
    if (!toastContainer) return;

    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.innerHTML = `
        <i class="fa-solid ${iconClass}"></i>
        <span>${message}</span>
    `;

    toastContainer.appendChild(toast);

    // Trigger enter animation
    setTimeout(() => {
        toast.classList.add('show');
    }, 50);

    // Auto remove after 3.5 seconds
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => {
            toast.remove();
        }, 400);
    }, 3500);
}
